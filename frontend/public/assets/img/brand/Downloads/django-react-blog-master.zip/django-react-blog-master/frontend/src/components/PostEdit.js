import React, { Component, PropTypes } from 'react';
import ReactDOM from 'react-dom';

import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import * as actionCreators from '../actions/index';

import { FormGroup, FieldGroup, FormControl, ControlLabel, Button } from 'react-bootstrap';
import { IndexLinkContainer, LinkContainer } from 'react-router-bootstrap';

import SimpleMDE from 'react-simplemde-editor';


class PostEdit extends Component {
    /* Access properties from context */
    /* Router creates context, and this thing takes it */
    static contextTypes = {
	router: PropTypes.object
    };

    constructor(props){
	super(props);
	/* Set empty state to avoid errors before post is fetched */
	this.state = { title: "",
		       body:"",
		       published: false,
		       tags: "",
		       category: ""};
	
	/* So that I would be able to access this component with "this"
	   inside the functions: */
	this.onTitleChange = this.onTitleChange.bind(this);
	this.onBodyChange = this.onBodyChange.bind(this);	
	this.onTagsChange = this.onTagsChange.bind(this);
	this.onCategoryChange = this.onCategoryChange.bind(this);
	this.onPublishClick = this.onPublishClick.bind(this);		
    }
    
    componentWillMount() {
	/* this.props.params.slug is the post slug passed here by the router.
	   If it's there - I want to fetch the post,
	   and populate the form with it's data.
	   If it isn't there - that means I'm at the "/post/new",
	   and I'll have an empty form for writing a new post. */
	if (this.props.params.slug) {
	    /* call action creator */
	    /* action creator will fetch the post from the API   */
	    /* and send it to the reducer */
	    /* reducer will add it to the redux state */
	    /* Which will be rendered into the form */
	    this.props.fetchPost(this.props.params.slug);
	}
	this.props.fetchCategories();
    }


    componentWillReceiveProps(nextProps) {
	/* Once the post has been fetched, add it to the state.
	   I can't do this in componentWillMount() because I gotta wait for
	   fetchPost() to complete, and I can't use the promise,
	   because action creator has to return the action object, not a promise.*/
	const { post } =  nextProps;
	/* console.log("Received props! Body: " + post.body);*/
	if (post) {
	    var category = "";
	    if (post.category) {category = post.category.slug};
	    var tags=""
	    /* Turn the list of tag objects into comma separated list of tag titles. */
	    if (post.tags) {
		tags = post.tags.map((tag) => {
		    return tag.title;
		}).join(", ");
	    }
	    this.setState({
		body: post.body,
		title: post.title,
		published: post.published,		
		tags: tags,
		category: category
	    });
	}
    }

    /* Every time I type into the form - update the state. */
    /* There's probably a smarter way to do this. */
    onTitleChange(event) {
	this.setState({ title: event.target.value });
    };
    onBodyChange(value) {
	this.setState({ body: value });
    };
    onTagsChange(event) {
	this.setState({ tags: event.target.value });
    };
    onCategoryChange(event) {
	const selectedCategory = ReactDOM.findDOMNode(this.select).value;
	console.log("Selected category: " + selectedCategory);
	this.setState({ category: selectedCategory });	
    };
    onPublishClick(event) {
	/* Flip published state */
	/* this.setState({ published: !this.state.published });	*/

	const { body, title, tags, category } = this.state;
	const published = !this.state.published;
	const post = { title, body, published, tags, category };
	this.props.updatePost(this.props.params.slug, post);
    }
    onSubmit(event) {
	/* Handle submit */
	/* Stop the default event(so that submitting form wouldn't reload thep page) */
	event.preventDefault();
	/* Grabbing all the form data from the state */
	const { body, title, tags, category } = this.state;

	/* Creating a post object */
	const post = { title, body, tags, category };
	/* console.log("Sending post to API. Slug: " + this.props.params.slug);*/

	if (this.props.params.slug) {
	    /* If the router passes the slug to this component,
	       that means I'm editing the post, and I want to update it */
	/* Calling an action creator, sending the post to the api */
	    this.props.updatePost(this.props.params.slug, post);
	} else {
	    /* If there's no this.props.params.slug, that means
	       I am at the "/post/new", and I want to create a new post*/
	    this.props.createPost(post);	    
	}
	
    }

    onDelete() {
	/* Calling an action creator that deletes the post */
	this.props.deletePost(this.props.params.slug);
    }
    

    renderCategories(){
	const categories = this.props.categories.results;

	if (!categories || categories.length == 0) { return null; };

	const categories_list = categories.map((category) => {
	    return (
		<option key={category.slug} value={category.slug}>
			{category.title}
		</option>
	    );
	});

	return (
	    <FormControl ref={select => { this.select = select }}
	                 onChange={this.onCategoryChange}
	                 value={this.state.category}
	                 componentClass="select"
	                 className="select-categories">
		<option value="">Category</option>
		{ categories_list }
	    </FormControl>
	);
    }

    renderDeleteButton () {
	/* If I'm editing a post (and not creating a new one) - render delete button. */
	if (this.props.params.slug) {
	    return (	
		    <Button onClick={this.onDelete.bind(this)}>
			Delete Post
		    </Button>
	    );
	} else {
	    return null;
	}

    }

    renderPublishButton () {
	if (!this.props.post) {return null;}
	console.log("State: \n" + JSON.stringify(this.state));
	if (!this.state.published) {
	    return (	
		    <Button onClick={this.onPublishClick}>Publish</Button>
	    );
	    } else {
		return (	
			<Button onClick={this.onPublishClick}>Un-Publish</Button>
		);
	}
    }

    
    render() {
	/* Grabbing the post from the redux state
	   (connected to this component at the end of this file) */
	const categories = this.props.categories;
	var noCategories = false;
	if (categories.results) {
	    /* If categories have been fetched - check if user has created any */
	    if (categories.results.length == 0) {
		/* If there are no categories -
		   then we'll want tags input to be fullwidth */
		noCategories = true;
	    }
	}
	/* 
	console.log("> Current state: ");
	console.log("Title: " + this.state.title);		
	console.log("Body: " + this.state.body);
	console.log("Tags: " + this.state.tags);	
	 */

	return (
	    <div>
		<br/>
		<form onSubmit={this.onSubmit.bind(this)}>
		    <FormGroup>
			{/* Title */}						
			<FormControl className="postTitle"
				     type="text"
				     placeholder="Post Title"
				     value={this.state.title}
				     onChange={this.onTitleChange}/>

			{/* Body */}
			<SimpleMDE
			    onChange={this.onBodyChange}
			    value={this.state.body}
			    options={{
				spellChecker: false,
				placeholder: "Write here...",
				initialValue: this.state.body,
				autosave: {
				    enabled: false,
				    delay: 1000,
				    uniqueId: "NewPost",
				    delay: 1000,
				},				
			    }}/>

			{/* Categories */}
			{ this.renderCategories() }
			{/* Tags.
			    If there are no categories - I'm not rendering
			    the categories selector, so I need to make the
			    width 100%. */}			
			<FormControl className={"post-tags" +
						 (noCategories ? "force-fullwidth" : "")}
				     type="text"
				     placeholder="tag1, tag2, tag3"
				     value={this.state.tags}
				     onChange={this.onTagsChange}/>
			<div className="clearfix"></div>
			<br/>

			{ this.renderDeleteButton() } 

			<div className="right">
			    <IndexLinkContainer to={{ pathname: '/'}}>
				<Button type="submit">Cancel</Button>
			    </IndexLinkContainer> &nbsp;
			    { this.renderPublishButton() }  &nbsp;
			    <Button bsStyle="primary" type="submit">Save</Button>
			</div>
		    </FormGroup>
		    <br/><br/>
		</form>
	    </div>
	);
    }
}




function mapStateToProps(state) {
    return {
	post:state.posts.post,
	categories: state.categories.all
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators(actionCreators, dispatch);
}


export default connect(mapStateToProps, mapDispatchToProps)(PostEdit);
